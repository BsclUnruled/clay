use std::rc::Rc;

use crate::clay::var::VarBox;
pub fn escape(s: &str) -> String{
    // todo!("Error:escape尚未完成")
    println!("Error:escape尚未完成");
    s.to_string()
}
pub fn template(s: &str,_:Rc<VarBox>) -> String{
    //todo!("Error:template尚未完成")
    println!("Error:template尚未完成");
    s.to_string()
}
